Group composed of :
Axel Bertrand
Pierre-Elliott Thiboud